export // simple typedefs
const UserShape = {
name: '',
email: ''
};